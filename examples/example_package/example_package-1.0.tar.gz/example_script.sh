# examples/example_package/example_script.sh

#!/bin/bash
# Пример скрипта для демонстрации упаковки в RPM

echo "Привет, это пример скрипта, упакованного в RPM!"
